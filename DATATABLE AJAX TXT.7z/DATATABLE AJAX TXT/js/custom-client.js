function getSocialIcon(sType, isButton) {

                        var iconClass = '';
                        switch (sType) {
                            case 'Facebook':
                                iconClass = !isButton ? "fa crm-fa fa-facebook" : "btn-facebook";
                                break;
                            case 'Linkedin':
                                iconClass = !isButton ? "fa crm-fa fa-linkedin" : "btn-linkedin";
                                break;
                            case 'Skype':
                                iconClass = !isButton ? "fa crm-fa fa-skype" : "btn-twitter";
                                break;

                            case 'Twitter':
                                iconClass = !isButton ? "fa crm-fa fa-twitter" : "btn-twitter";
                                break;

                            case 'Whatsapp':
                                iconClass = !isButton ? "fa crm-fa fa-whatsapp" : "bg-lime-active";
                                break;

                            case 'Google+':
                                iconClass = !isButton ? "fa crm-fa fa-google-plus" : "btn-google";
                                break;

                            case 'Snapchat':
                                iconClass = !isButton ? "fa crm-fa fa-snapchat-ghost" : "bg-yellow-active";
                                break;


                        }
                        return iconClass;

                    }

////
function getAddress2(address2) {
	
	var htmlAddress2 = '<br/>'+
  ' <cite title="">'+address2+''+
   ' <i class="glyphicon glyphicon-map-marker">'+
   ' </i>'+
' </cite>';

	if(formatData(address2) != '')                  
		return htmlAddress2 ;
	return '';
}

function getCustomerImage(objData) {
	
	//console.log(objData.AttachmentFiles.results[0]);
	if(objData.AttachmentFiles.results != null && objData.AttachmentFiles.results[0] != null) {
		return objData.AttachmentFiles.results[0].ServerRelativeUrl;
	}
	return 'images/150x100.png';
}

// Get Social Links
function getSocialLink(sType) {
    var link = '';
    switch (sType) {
        case 'Facebook':
            link = "www.facebook.com";
            break;
        case 'Linkedin':
            link = "www.linkedin.com";
            break;
        case 'Skype':
            link = "www.web.skype.com";
            break;

        case 'Twitter':
            link = "www.twitter.com";
            break;

        case 'Whatsapp':
            link = "www.web.whatsapp.com/";
            break;

        case 'Google+':
            link = "www.plus.google.com/";
            break;

        case 'Snapchat':
            link = "www.snapchat.com";
            break;
    }
    return link;

}

function redirectLink(link) {
	//alert(link)
	window.open('https://'+link, '_blank');
	//onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE1)+'");return false;
	return false;
}

function getSocialLinks(objCustomer) {

    var htmlSocialLinks = '';
    $('#spanSLink2').html('');
	var     html = '							<a class="btn btn-circle btn-social-icon btn-facebook text-white"><i class="fa fa-facebook"></i></a>';
    if (formatData(objCustomer.SOCIALLINK1) != '')
        htmlSocialLinks += '<button onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE1)+'");return false;  class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE1,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE1) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK2) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE2)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE2,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE2) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK3) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE3)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE3,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE3) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK4) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE4)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE4,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE4) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK5) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE5)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE5,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE5) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK6) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE6)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE6,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE6) + '" id="spanSlinkIcon"></i></button>';
    if (formatData(objCustomer.SOCIALLINK7) != '')
        htmlSocialLinks += '<button  onclick=redirectLink("'+getSocialLink(objCustomer.SOCIALLINKTYPE7)+'");return false; class="btn btn-circle btn-social-icon '+getSocialIcon(objCustomer.SOCIALLINKTYPE7,true)+'"><i class="' + getSocialIcon(objCustomer.SOCIALLINKTYPE7) + '" id="spanSlinkIcon"></i></button>';

    if(htmlSocialLinks == '')
    	$('#spanSLink2').hide();
    else 
    	$('#spanSLink2').show();
    //alert(htmlSocialLinks)
    return htmlSocialLinks;

}

function showMessage(message) {
    $("#snackbar").val(message);
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function () { x.className = x.className.replace("show", ""); }, 3000);
    return false;
}
////Remove null values from the data
function formatData(data) {
    return data == 'NULL' || data == null || data == 'null' ? '' : data;
}

////Get Query String from the URL
function GetParameterValues(param) {
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0].toLowerCase() == param.toLowerCase()) {
            return urlparam[1];
        }
    }
}

function getListItemsCount() {

	    var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata/_api/Web/Lists/getByTitle('TBL_CONTACT')/ItemCount";
	    $.ajax({
              url: requestUri,
              type: "GET",
              async:false,
              headers: {
                  "accept":"application/json; odata=verbose"
              },
              success: function(data) {
              	//alert(getListItemsCount());
				var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata" + "/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top=5000&$select=AttachmentFiles,ID,ZIP,CITY,STATE,CONTACT1,CONTACT2,CONTACT3,CONTACT4,CONTACT5,CONTACT6,CONTACT7,CONTACTTYPE1,CONTACTTYPE2,CONTACTTYPE3,CONTACTTYPE4,CONTACTTYPE5,CONTACTTYPE6,CONTACTTYPE7,SOCIALLINK1,SOCIALLINKTYPE1,SOCIALLINK2,SOCIALLINKTYPE2,SOCIALLINK3,SOCIALLINKTYPE3,SOCIALLINK4,SOCIALLINKTYPE4,SOCIALLINK5,SOCIALLINKTYPE5,SOCIALLINK6,SOCIALLINKTYPE6,SOCIALLINK7,SOCIALLINKTYPE7,FULLNAME,ADDRESS1,ADDRESS2,COUNTRY,SALUTATION,JOBTITLE,DEPARTMENT&$expand=AttachmentFiles&$filter=((FULLNAME ne 'NULL') and (FULLNAME ne '?')) ";
			    $('#tblClients').DataTable( {
			        //"processing": true,
			        //"serverSide": true,
			        //"ajax": requestUri,
			       	"sPaginationType": "full_numbers",
		 	     	 "paging": true,
		 	     	 //"ajax": 'https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/test.txt',
		 	     //	 "ajax":{"url":"https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/test.txt","dataSrc":""},
		 	     //	  "columns" : [
           // { "data" : "ID" },
              //     ]
			        
			        //"deferLoading": data.d.ItemCount
			    } );
 
	    
        	$(".animationload").hide();
			//getAllClients(5000);
			    
             // return data.d.ItemCount;
              
              },
              error: function() {
              
              }
	});


}

function getClientsFromFile() {

$('#tblClients').DataTable( {
        "ajax": "client.txt",
        //"columns": [
        //    { "data": "FULLNAME" }
        //    //{ "data": "position" },
        //    //{ "data": "office" },
        //    //{ "data": "extn" },
        //    //{ "data": "start_date" },
        //    //{ "data": "salary" }
        //]
        "columnDefs": [
           {
               // The `data` parameter refers to the data for the cell (defined by the
               // `data` option, which defaults to the column being worked with, in
               // this case `data: 0`.
               "render": function (data, type, row) {
               var tableContent  = '';
               		  tableContent += ''+
                    '<div class="row" style="    margin-top: 5px;">'+
                        '<div class="col-xs-12 col-sm-6 col-md-12" style=";margin: 0px;">'+
                            '<div class="well well-sm">'+
                               ' <div class="row" style="height:150px">'+
                                    '<div class="col-sm-6 col-md-2" style="margin-right: 1px;">'+
                                        '<img src="'+getCustomerImage(row)+'" alt="" class="img-rounded img-responsive" style="width:150px;height:120px" />'+
                                    '</div>'+
                                    '<div class="col-sm-6 col-md-9">'+
                                       ' <h5>'+
                                           ' <a target=_self href=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/ClientDetail.aspx?ID='+row["ID"]+'&Source=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/Client.aspx style=text-decoration:underline>' +row["FULLNAME"]+'</a></h5>'+
                                       ' <small>'+
                                           ' <cite title="">'+formatData(row["ADDRESS1"])+''+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite>'+

                                       ' </small>'+
                                       '<small>'+
                                       getAddress2(formatData(row["ADDRESS2"]))+
                                       '</small>'+
                                       ' <small><br/>'+
                                           ' <cite title="">'+formatData(row["CITY"])+', '+formatData(row["STATE"])+', '+formatData(row["ZIP"])+''+
                                              '  <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite><br/>'+
                                            '<cite title="">'+formatData(row["CONTACT1"])+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                                '</i>'+
                                          '  </cite>'+
                                       ' </small>'+
                                      ' <br/><br/><br/>'+
                                           ' <div style="    position: relative;    top: -150px;    float: right;    right: -90px;">'+
                                               ' <span id="spanSLink2" style="display:block">'+
													getSocialLinks(row)+
                                             ' </span>'+
          
                                           ' </div>'+
                                           ' <div style="position: relative;    top: -3px;    float: right;    right: -275px;display:none">'+
                                               ' <span style="font-size: 12px;">'+formatData(row["STATUS"])+'</span>'+
                                           ' </div>'+
                                            
                                           ' <div style="margin-top: -3px;display:none">'+
                                                '<span style="font-size: 12px;">'+formatData(row["CONTACT1"])+'</span>'+
                                           ' </div>'+
                                      
                                   ' </div>'+
                               ' </div>'+
                            '</div>'+
                       ' </div>'+
                   ' </div>';
           

                   return tableContent;//'<td style="width:100%" class="sorting_1"><div class="row" style="    margin-top: 5px;"><div class="col-xs-12 col-sm-6 col-md-12" style=";margin: 0px;"><div class="well well-sm"> <div class="row" style="height:150px"><div class="col-sm-6 col-md-2" style="margin-right: 1px;"><img src="/sites/DSGData/Lists/TBL_CONTACT/Attachments/802/dsg_logo.png" alt="" class="img-rounded img-responsive" style="width:150px;height:120px"></div><div class="col-sm-6 col-md-9"> <h5> <a target="_self" href="https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/ClientDetail.aspx?ID=802&amp;Source=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/Client.aspx" style="text-decoration:underline">'+row["FULLNAME"]+'</a></h5> <small> <cite title="">New York <i class="glyphicon glyphicon-map-marker"> </i> </cite> </small><small><br> <cite title="">ST. 5 <i class="glyphicon glyphicon-map-marker"> </i> </cite></small> <small><br> <cite title="">New York City, NY, 55555  <i class="glyphicon glyphicon-map-marker"> </i> </cite><br><cite title="">+123456852 <i class="glyphicon glyphicon-map-marker"></i>  </cite> </small> <br><br><br> <div style="    position: relative;    top: -150px;    float: right;    right: -90px;"> <span id="spanSLink2" style="display:block"><button onclick="redirectLink(&quot;www.facebook.com&quot;);return" false;="" class="btn btn-circle btn-social-icon btn-facebook"><i class="fa crm-fa fa-facebook" id="spanSlinkIcon"></i></button><button onclick="redirectLink(&quot;www.plus.google.com/&quot;);return" false;="" class="btn btn-circle btn-social-icon btn-google"><i class="fa crm-fa fa-google-plus" id="spanSlinkIcon"></i></button><button onclick="redirectLink(&quot;www.web.skype.com&quot;);return" false;="" class="btn btn-circle btn-social-icon btn-twitter"><i class="fa crm-fa fa-skype" id="spanSlinkIcon"></i></button> </span> </div> <div style="position: relative;    top: -3px;    float: right;    right: -275px;display:none"> <span style="font-size: 12px;"></span> </div> <div style="margin-top: -3px;display:none"><span style="font-size: 12px;">+123456852</span> </div> </div> </div></div> </div> </div> </td>';
               },
               "targets": 0
           },
           { }
        ],
        "initComplete": function( settings, json ) {
		    $(".animationload").hide();
		  }
    } );
    //$(".animationload").hide();
return false;

}

function getClients(top) {


		
       //	var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata" + "/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top="+top+"&$select=AttachmentFiles,ID,ZIP,CITY,STATE,CONTACT1,CONTACT2,CONTACT3,CONTACT4,CONTACT5,CONTACT6,CONTACT7,CONTACTTYPE1,CONTACTTYPE2,CONTACTTYPE3,CONTACTTYPE4,CONTACTTYPE5,CONTACTTYPE6,CONTACTTYPE7,SOCIALLINK1,SOCIALLINKTYPE1,SOCIALLINK2,SOCIALLINKTYPE2,SOCIALLINK3,SOCIALLINKTYPE3,SOCIALLINK4,SOCIALLINKTYPE4,SOCIALLINK5,SOCIALLINKTYPE5,SOCIALLINK6,SOCIALLINKTYPE6,SOCIALLINK7,SOCIALLINKTYPE7,FULLNAME,ADDRESS1,ADDRESS2,COUNTRY,SALUTATION,JOBTITLE,DEPARTMENT&$expand=AttachmentFiles&$filter=((FULLNAME ne 'NULL') and (FULLNAME ne '?'))&$orderby=Created desc";
       	  	var requestUri = "https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/client.txt";
//        alert(requestUri);
           $.ajax({
              url: requestUri,
              type: "GET",
              cache:true,
              headers: {
                  "accept":"application/json; odata=verbose"
              },
              success: onSuccess,
              error: onError
	});

  function onSuccess(data) {
     //var objItems = data.d.results;
//     console.log(data.d.results);
	var objItems = jQuery.parseJSON(data);
     var dataLength = objItems != null ? objItems.length : 0;
     var tableContent = '';
      var jsonString = JSON.stringify(objItems);
      //$('#datajson').html(jsonString);
  		$('#animationload').show();
     for (var i = 0; i < dataLength; i++) {
       tableContent += '<tr>';
         tableContent += '<td style="width:100%">'+
                    '<div class="row" style="    margin-top: 5px;">'+
                        '<div class="col-xs-12 col-sm-6 col-md-12" style=";margin: 0px;">'+
                            '<div class="well well-sm">'+
                               ' <div class="row" style="height:150px">'+
                                    '<div class="col-sm-6 col-md-2" style="margin-right: 1px;">'+
                                        '<img src="'+getCustomerImage(objItems[i])+'" alt="" class="img-rounded img-responsive" style="width:150px;height:120px" />'+
                                    '</div>'+
                                    '<div class="col-sm-6 col-md-9">'+
                                       ' <h5>'+
                                           ' <a target=_self href=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/ClientDetail.aspx?ID='+objItems[i].ID+'&Source=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/Client.aspx style=text-decoration:underline>' +objItems[i].FULLNAME  +'</a></h5>'+
                                       ' <small>'+
                                           ' <cite title="">'+formatData(objItems[i].ADDRESS1)+''+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite>'+

                                       ' </small>'+
                                       '<small>'+
                                       getAddress2(formatData(objItems[i].ADDRESS2))+
                                       '</small>'+
                                       ' <small><br/>'+
                                           ' <cite title="">'+formatData(objItems[i].CITY)+', '+formatData(objItems[i].STATE)+', '+formatData(objItems[i].ZIP)+''+
                                              '  <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite><br/>'+
                                            '<cite title="">'+formatData(objItems[i].CONTACT1)+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                                '</i>'+
                                          '  </cite>'+
                                       ' </small>'+
                                      ' <br/><br/><br/>'+
                                           ' <div style="    position: relative;    top: -150px;    float: right;    right: -90px;">'+
                                               ' <span id="spanSLink2" style="display:block">'+
													getSocialLinks(objItems[i])+
                                             ' </span>'+
          
                                           ' </div>'+
                                           ' <div style="position: relative;    top: -3px;    float: right;    right: -275px;display:none">'+
                                               ' <span style="font-size: 12px;">'+formatData(objItems[i].STATUS)+'</span>'+
                                           ' </div>'+
                                            
                                           ' <div style="margin-top: -3px;display:none">'+
                                                '<span style="font-size: 12px;">'+formatData(objItems[i].CONTACT1)+'</span>'+
                                           ' </div>'+
                                      
                                   ' </div>'+
                               ' </div>'+
                            '</div>'+
                       ' </div>'+
                   ' </div>'+
           
           ' </td>';
                    tableContent += '</tr>';
                    
 }
                   //tableContent += '</tbody>';
		   $('#tbodyClients').append(tableContent); 
		   getListItemsCount(); 
		//  $('#tblClients').DataTable( {
		//       "sPaginationType": "full_numbers",
		 //      "paging": true
		//    } );
    
        //	$(".animationload").hide();
   }
    function onError(error) {
    	
    	$(".animationload").hide();
        alert('Error');       
   }


}

$(function(){
	
	$(document).ready(function(){
	//$(window).on("load", function() {
       // var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata" + "/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top=5000&$filter=((FULLNAME ne 'NULL') and (FULLNAME ne '?')) ";	
	 //setLocalStorage();
	 //ajxLoad();
	 //getClients(5000); 
	 getClientsFromFile();
	 
	  

	 
	 
  });
});



function getAllClients(top) {


		
       	var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata" + "/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top="+top+"&$select=AttachmentFiles,ID,ZIP,CITY,STATE,CONTACT1,CONTACT2,CONTACT3,CONTACT4,CONTACT5,CONTACT6,CONTACT7,CONTACTTYPE1,CONTACTTYPE2,CONTACTTYPE3,CONTACTTYPE4,CONTACTTYPE5,CONTACTTYPE6,CONTACTTYPE7,SOCIALLINK1,SOCIALLINKTYPE1,SOCIALLINK2,SOCIALLINKTYPE2,SOCIALLINK3,SOCIALLINKTYPE3,SOCIALLINK4,SOCIALLINKTYPE4,SOCIALLINK5,SOCIALLINKTYPE5,SOCIALLINK6,SOCIALLINKTYPE6,SOCIALLINK7,SOCIALLINKTYPE7,FULLNAME,ADDRESS1,ADDRESS2,COUNTRY,SALUTATION,JOBTITLE,DEPARTMENT&$expand=AttachmentFiles&$filter=((FULLNAME ne 'NULL') and (FULLNAME ne '?')) ";
//        alert(requestUri);
           $.ajax({
              url: requestUri,
              type: "GET",
              async:true,
              headers: {
                  "accept":"application/json; odata=verbose"
              },
              success: onSuccess,
              error: onError
	});

  function onSuccess(data) {
     var objItems = data.d.results;
     console.log(objItems.length);
     var dataLength = objItems != null ? objItems.length : 0;
     var tableContent = '';

     for (var i = 0; i < dataLength; i++) {
       tableContent += '<tr>';
         tableContent += '<td style="width:100%">'+
                    '<div class="row" style="    margin-top: 5px;">'+
                        '<div class="col-xs-12 col-sm-6 col-md-12" style=";margin: 0px;">'+
                            '<div class="well well-sm">'+
                               ' <div class="row" style="height:150px">'+
                                    '<div class="col-sm-6 col-md-2" style="margin-right: 1px;">'+
                                        '<img src="'+getCustomerImage(objItems[i])+'" alt="" class="img-rounded img-responsive" style="width:150px;height:120px" />'+
                                    '</div>'+
                                    '<div class="col-sm-6 col-md-9">'+
                                       ' <h5>'+
                                           ' <a target=_self href=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/ClientDetail.aspx?ID='+objItems[i].ID+'&Source=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/Client.aspx style=text-decoration:underline>' +objItems[i].FULLNAME  +'</a></h5>'+
                                       ' <small>'+
                                           ' <cite title="">'+formatData(objItems[i].ADDRESS1)+''+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite>'+

                                       ' </small>'+
                                       '<small>'+
                                       getAddress2(formatData(objItems[i].ADDRESS2))+
                                       '</small>'+
                                       ' <small><br/>'+
                                           ' <cite title="">'+formatData(objItems[i].CITY)+', '+formatData(objItems[i].STATE)+', '+formatData(objItems[i].ZIP)+''+
                                              '  <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite><br/>'+
                                            '<cite title="">'+formatData(objItems[i].CONTACT1)+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                                '</i>'+
                                          '  </cite>'+
                                       ' </small>'+
                                      ' <br/><br/><br/>'+
                                           ' <div style="    position: relative;    top: -150px;    float: right;    right: -90px;">'+
                                               ' <span id="spanSLink2" style="display:block">'+
													getSocialLinks(objItems[i])+
                                             ' </span>'+
          
                                           ' </div>'+
                                           ' <div style="position: relative;    top: -3px;    float: right;    right: -275px;display:none">'+
                                               ' <span style="font-size: 12px;">'+formatData(objItems[i].STATUS)+'</span>'+
                                           ' </div>'+
                                            
                                           ' <div style="margin-top: -3px;display:none">'+
                                                '<span style="font-size: 12px;">'+formatData(objItems[i].CONTACT1)+'</span>'+
                                           ' </div>'+
                                      
                                   ' </div>'+
                               ' </div>'+
                            '</div>'+
                       ' </div>'+
                   ' </div>'+
           
           ' </td>';
                    tableContent += '</tr>';
                    
 }
 		localStorage.setItem('clientsStorage', JSON.stringify(objItems));
 		var obj = JSON.parse(localStorage.getItem('clientsStorage'));//alert(obj.length);
                   //tableContent += '</tbody>';
		   ///$('#tbodyClients').append(tableContent); 
		   	$('#tblClients').DataTable().destroy();
	$('#tbodyClients').html('');
	$('#tbodyClients').append(tableContent);
	$('#tblClients').DataTable({
		"sPaginationType": "full_numbers",
	    //"paging": false,
	    //"ordering": false
	
	}).draw();

		   //getListItemsCount(); 
		//  $('#tblClients').DataTable( {
		//       "sPaginationType": "full_numbers",
		 //      "paging": true
		//    } );
    
        //	$(".animationload").hide();
   }
    function onError(error) {
    	
    	$(".animationload").hide();
        alert('Error');       
   }


}

function ajxLoad() {

   //var aDemoItems  = oResults.lDemographicItems; //
    //var jsonString = JSON.stringify(aDemoItems  )
  //$('#tblClients').DataTable( {
    //    "ajax": 'https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/test.txt'
    //} );
    
    
    	$('#tblClients').DataTable().destroy();
		$('#tblClients').DataTable({
			"ajax": 'https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/test.txt'
		
		}).draw();


}

function setLocalStorage(count) {
	
	var top = count == null ? 5000 : count;
	var requestUri = "https://appriver3651010904.sharepoint.com/sites/dsgdata" + "/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top="+top+"&$select=AttachmentFiles,ID,ZIP,CITY,STATE,CONTACT1,CONTACT2,CONTACT3,CONTACT4,CONTACT5,CONTACT6,CONTACT7,CONTACTTYPE1,CONTACTTYPE2,CONTACTTYPE3,CONTACTTYPE4,CONTACTTYPE5,CONTACTTYPE6,CONTACTTYPE7,SOCIALLINK1,SOCIALLINKTYPE1,SOCIALLINK2,SOCIALLINKTYPE2,SOCIALLINK3,SOCIALLINKTYPE3,SOCIALLINK4,SOCIALLINKTYPE4,SOCIALLINK5,SOCIALLINKTYPE5,SOCIALLINK6,SOCIALLINKTYPE6,SOCIALLINK7,SOCIALLINKTYPE7,FULLNAME,ADDRESS1,ADDRESS2,COUNTRY,SALUTATION,JOBTITLE,DEPARTMENT&$expand=AttachmentFiles&$filter=((FULLNAME ne 'NULL') and (FULLNAME ne '?')) ";
	//        alert(requestUri);
	$.ajax({
	  url: requestUri,
	  type: "GET",
	  async:true,
	  headers: {
	      "accept":"application/json; odata=verbose"
	  },
	  success: function(data) {
	  
	  		var objItems = data.d.results;
	  		localStorage.clear();
	  		localStorage.setItem('clientsStorage', JSON.stringify(objItems));
	  		console.log('clientsStorage:' + objItems.length);
	  		$('#btnLoadAllData').removeAttr('disabled');
	  			  		$('#btnLoadAllData').text('Load All');
	  		$('#btnLoadAllData').show();
	  
	  },
	  error: function() {
	  
	  }
	});
}


function getLocalStorage() {

	 var obj = JSON.parse(localStorage.getItem('clientsStorage'));
	 if(obj != null && obj.length > 0) {
	 
	 	return obj;
	 }
	 else {
	 	
	 	setLocalStorage();
	 
	 }
	 
	 return null;
}

function createDataTable(isNew, objItems) {

  	if(isNew) {
	  	$('#tblClients').DataTable( {
	       "sPaginationType": "full_numbers",
	      "paging": true
	    } );
    }
    else {
    	
    	$('#tblClients').DataTable().destroy();
    	createTableBody(objItems, 'tbodyClients');
		$('#tblClients').DataTable({
			"sPaginationType": "full_numbers",
		    "paging": true,
		    "ordering": false
		
		}).draw();

    
    }
return false;

}

function loadAll() {

	$('#btnLoadAllData').attr('disabled','disabled');
	$('#btnLoadAllData').text('Please Wait....');
	  		$('.animationload').css("display","block");
			$(".animationload").show();
			var load = setTimeout(function() {
   $(".animationload").show();
   	
   	var objItems = getLocalStorage();
	if(objItems != null) {
	

		createDataTable(false, objItems);
		$('#btnLoadAllData').removeAttr('disabled');
		$('#btnLoadAllData').text('Load All');
//		    	$(".animationload").hide();
		
	}
   
   }, 2000);
	
	return false;

}


function createTableBody(objItems, tBodyId) {

	var dataLength = objItems != null ? objItems.length : 0;
     var tableContent = '';
     for (var i = 0; i < dataLength; i++) {
       tableContent += '<tr>';
         tableContent += '<td style="width:100%">'+
                    '<div class="row" style="    margin-top: 5px;">'+
                        '<div class="col-xs-12 col-sm-6 col-md-12" style=";margin: 0px;">'+
                            '<div class="well well-sm">'+
                               ' <div class="row" style="height:150px">'+
                                    '<div class="col-sm-6 col-md-2" style="margin-right: 1px;">'+
                                        '<img src="'+getCustomerImage(objItems[i])+'" alt="" class="img-rounded img-responsive" style="width:150px;height:120px" />'+
                                    '</div>'+
                                    '<div class="col-sm-6 col-md-9">'+
                                       ' <h5>'+
                                           ' <a target=_self href=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/ClientDetail.aspx?ID='+objItems[i].ID+'&Source=https://appriver3651010904.sharepoint.com/sites/RegionTest/SitePages/Client.aspx style=text-decoration:underline>' +objItems[i].FULLNAME  +'</a></h5>'+
                                       ' <small>'+
                                           ' <cite title="">'+formatData(objItems[i].ADDRESS1)+''+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite>'+

                                       ' </small>'+
                                       '<small>'+
                                       getAddress2(formatData(objItems[i].ADDRESS2))+
                                       '</small>'+
                                       ' <small><br/>'+
                                           ' <cite title="">'+formatData(objItems[i].CITY)+', '+formatData(objItems[i].STATE)+', '+formatData(objItems[i].ZIP)+''+
                                              '  <i class="glyphicon glyphicon-map-marker">'+
                                               ' </i>'+
                                           ' </cite><br/>'+
                                            '<cite title="">'+formatData(objItems[i].CONTACT1)+
                                               ' <i class="glyphicon glyphicon-map-marker">'+
                                                '</i>'+
                                          '  </cite>'+
                                       ' </small>'+
                                      ' <br/><br/><br/>'+
                                           ' <div style="    position: relative;    top: -150px;    float: right;    right: -90px;">'+
                                               ' <span id="spanSLink2" style="display:block">'+
													getSocialLinks(objItems[i])+
                                             ' </span>'+
          
                                           ' </div>'+
                                           ' <div style="position: relative;    top: -3px;    float: right;    right: -275px;display:none">'+
                                               ' <span style="font-size: 12px;">'+formatData(objItems[i].STATUS)+'</span>'+
                                           ' </div>'+
                                            
                                           ' <div style="margin-top: -3px;display:none">'+
                                                '<span style="font-size: 12px;">'+formatData(objItems[i].CONTACT1)+'</span>'+
                                           ' </div>'+
                                      
                                   ' </div>'+
                               ' </div>'+
                            '</div>'+
                       ' </div>'+
                   ' </div>'+
           
           ' </td>';
                    tableContent += '</tr>';
                    
 }
	
		$('#'+tBodyId).html('');
		$('#'+tBodyId).append(tableContent);
		$(".animationload").hide();
			$('#btnLoadAllData').text('Load All');

}