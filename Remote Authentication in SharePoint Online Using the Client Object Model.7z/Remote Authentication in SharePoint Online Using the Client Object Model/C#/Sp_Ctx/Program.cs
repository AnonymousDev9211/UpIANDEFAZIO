﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Client;
using System.Net;
using MSDN.Samples.ClaimsAuth;
using System.IO;
using System.Security;
using Newtonsoft.Json.Linq;

namespace Sp_Ctx
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            //if (args.Length < 1) { Console.WriteLine("https://appriver3651010904.sharepoint.com/sites/DSGData/"); return; }

            var passWord = new SecureString();
            foreach (var c in "Nok46301") passWord.AppendChar(c);
            var json = GetList(new Uri("https://appriver3651010904.sharepoint.com/sites/DSGData"), new SharePointOnlineCredentials("snisar@dsg-usa.com", passWord), "TBL_CONTACT");
            return;
            string targetSite = "https://appriver3651010904.sharepoint.com/sites/DSGData/";// args[0];
            using (ClientContext ctx = ClaimClientContext.GetAuthenticatedContext(targetSite))
            {
                if (ctx != null)
                {
                    ctx.Load(ctx.Web); // Query for Web
                    ctx.ExecuteQuery(); // Execute
                    Console.WriteLine(ctx.Web.Title);
                    Web web = ctx.Web;
                    var newFile = new FileCreationInformation
                    {
                        Content = System.IO.File.ReadAllBytes("TestClient.txt"),
                        Url = "https://appriver3651010904.sharepoint.com/sites/DSGData/Shared%20Documents/TestClient.txt",// Path.GetFileName(fileName)
                        Overwrite = true
                    };
                    var docs = ctx.Web.Lists.GetByTitle("Documents");
                    Microsoft.SharePoint.Client.File uploadFile = docs.RootFolder.Files.Add(newFile);
                    ctx.ExecuteQuery();
                }
            }
            Console.ReadLine();
        }

        public static JToken GetList(Uri webUri, ICredentials credentials, string listTitle)
        {
            using (var client = new WebClient())
            {
                client.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
                client.Credentials = credentials;
                client.Headers.Add(HttpRequestHeader.ContentType, "application/json;odata=verbose");
                client.Headers.Add(HttpRequestHeader.Accept, "application/json;odata=verbose");
                var endpointUri = new Uri("https://appriver3651010904.sharepoint.com/sites/dsgdata/_api/web/lists/getbytitle('TBL_CONTACT')/items?$top=5000");//;(webUri, string.Format("/_api/web/lists/getbytitle('{0}')", listTitle));
                var result = client.DownloadString(endpointUri);
                var t = JToken.Parse(result);
                return t["d"];
            }
        }

        private static void UploadFile()
        {
            string fileName = @"C:\AddUser.aspx";
            using (var context = new ClientContext("https://yourdomain.com"))
            {
                var passWord = new SecureString();
                foreach (var c in "YourPassword") passWord.AppendChar(c);
                context.Credentials = new SharePointOnlineCredentials("YourUsername", passWord);
                var web = context.Web;
                var newFile = new FileCreationInformation
                {
                    Content = System.IO.File.ReadAllBytes(fileName),
                    Url = Path.GetFileName(fileName)
                };
                var docs = web.Lists.GetByTitle("Pages");
                Microsoft.SharePoint.Client.File uploadFile = docs.RootFolder.Files.Add(newFile);
                context.ExecuteQuery();
            }

        }
    }
}
